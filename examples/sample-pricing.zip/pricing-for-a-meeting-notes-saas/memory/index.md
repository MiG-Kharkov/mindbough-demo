# Memory

* [I am a solo founder](20261002-1zq1mz.md) - I am a solo founder: show prices in euros, with the maths.
