# Memory

* [I am a solo founder](20261001-o06q6f.md) - I am a solo founder: show prices in euros, with the maths.
