# Memory

* [I am a solo founder](20261001-9n42n5.md) - I am a solo founder: show prices in euros, with the maths.
