# Memory

* [I am a solo founder](20261002-m4mdsy.md) - I am a solo founder: show prices in euros, with the maths.
