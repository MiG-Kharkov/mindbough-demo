# Thinking log

## 2026-10-02
* **Decision**: [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](/nodes/20261002-1vv2cj.md)
* **Decision**: [Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and…](/nodes/20261002-7oozee.md) answers [How to price the meeting-notes SaaS at launch](/nodes/20261002-44zism.md).
* **Status**: [Per seat](/nodes/20261002-k9ipbr.md) is rejected.
* **Status**: [Usage-based](/nodes/20261002-2rf2a6.md) is rejected.
* **Status**: [Flat tiers](/nodes/20261002-z78u4y.md) is accepted.
* **Creation**: “Pricing for a meeting-notes SaaS”, a conversation in the Mindbough demo.
