# Thinking log

## 2026-10-01
* **Decision**: [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](/nodes/20261001-i1npl1.md)
* **Decision**: [Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and…](/nodes/20261001-6wi2o9.md) answers [How to price the meeting-notes SaaS at launch](/nodes/20261001-s5m6y7.md).
* **Status**: [Per seat](/nodes/20261001-ked2x2.md) is rejected.
* **Status**: [Usage-based](/nodes/20261001-jiv9wz.md) is rejected.
* **Status**: [Flat tiers](/nodes/20261001-ele4wj.md) is accepted.
* **Creation**: “Pricing for a meeting-notes SaaS”, a conversation in the Mindbough demo.
