# Thinking log

## 2026-10-03
* **Decision**: [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](/nodes/20261003-lhuhrm.md)
* **Decision**: [Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and…](/nodes/20261003-p724w1.md) answers [How to price the meeting-notes SaaS at launch](/nodes/20261003-a69op0.md).
* **Status**: [Per seat](/nodes/20261003-u4yba4.md) is rejected.
* **Status**: [Usage-based](/nodes/20261003-q4a28m.md) is rejected.
* **Status**: [Flat tiers](/nodes/20261003-cc90pv.md) is accepted.
* **Creation**: “Pricing for a meeting-notes SaaS”, a conversation in the Mindbough demo.
