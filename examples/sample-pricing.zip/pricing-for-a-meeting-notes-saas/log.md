# Thinking log

## 2026-10-02
* **Decision**: [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](/nodes/20261002-xyp7z1.md)
* **Decision**: [Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and…](/nodes/20261002-1r0me9.md) answers [How to price the meeting-notes SaaS at launch](/nodes/20261002-asi77e.md).
* **Status**: [Per seat](/nodes/20261002-0ijed7.md) is rejected.
* **Status**: [Usage-based](/nodes/20261002-lwt9u6.md) is rejected.
* **Status**: [Flat tiers](/nodes/20261002-lvbmmf.md) is accepted.
* **Creation**: “Pricing for a meeting-notes SaaS”, a conversation in the Mindbough demo.
