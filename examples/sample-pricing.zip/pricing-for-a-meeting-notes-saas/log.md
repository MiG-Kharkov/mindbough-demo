# Thinking log

## 2026-10-01
* **Decision**: [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](/nodes/20261001-wigk6d.md)
* **Decision**: [Chose Flat tiers over Per seat, Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps…](/nodes/20261001-jkijun.md) answers [How to price the meeting-notes SaaS at launch](/nodes/20261001-mhyayc.md).
* **Status**: [Per seat](/nodes/20261001-vo2o9l.md) is rejected.
* **Status**: [Usage-based](/nodes/20261001-he22w9.md) is rejected.
* **Status**: [Flat tiers](/nodes/20261001-fjb3me.md) is accepted.
* **Creation**: “Pricing for a meeting-notes SaaS”, a conversation in the Mindbough demo.
