# Thinking log

## 2026-10-06
* **Decision**: [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](/nodes/20261006-z3qjjm.md), by human:me.
* **Decision**: [Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and…](/nodes/20261006-54ewe5.md) answers [How to price the meeting-notes SaaS at launch](/nodes/20261006-an3jvi.md), by human:me.
* **Creation**: A conversation started in the Mindbough demo, by human:me.
