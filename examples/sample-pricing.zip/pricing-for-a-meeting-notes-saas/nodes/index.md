# Thought tree

* [Pricing for a meeting-notes SaaS](20261001-q3cemn.md) - Question · open: We're launching a SaaS that turns meeting recordings into searchable notes.
  * [How to price the meeting-notes SaaS at launch](20261001-mhyayc.md) - Question · accepted: Answered: Chose Flat tiers over Per seat, Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Per seat](20261001-vo2o9l.md) - Thought · rejected: Not chosen: Simple, but heavy users eat the margin. Flat tiers was chosen.
    * [Usage-based](20261001-he22w9.md) - Thought · rejected: Not chosen: Fair, but the bills worry small teams. Flat tiers was chosen.
    * [Flat tiers](20261001-fjb3me.md) - Thought · accepted: A fixed price per team, with hours capped by tier.
      * [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](20261001-wigk6d.md) - Decision · accepted: Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50% off for beta teams.
    * [Chose Flat tiers over Per seat, Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps…](20261001-jkijun.md) - Decision · accepted: Chose Flat tiers over Per seat, Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Suggests Flat tiers: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.](20261001-vkicgk.md) - Finding · open: Suggests Flat tiers: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
