# Thought tree

* [Pricing for a meeting-notes SaaS](20261002-y5kwiv.md) - Question · open: We're launching a SaaS that turns meeting recordings into searchable notes.
  * [How to price the meeting-notes SaaS at launch](20261002-44zism.md) - Question · accepted: Answered: Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Per seat](20261002-k9ipbr.md) - Thought · rejected: Not chosen: Simple, but heavy users eat the margin. Flat tiers was chosen.
    * [Usage-based](20261002-2rf2a6.md) - Thought · rejected: Not chosen: Fair, but the bills worry small teams. Flat tiers was chosen.
    * [Flat tiers](20261002-z78u4y.md) - Thought · accepted: A fixed price per team, with hours capped by tier.
      * [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](20261002-1vv2cj.md) - Decision · accepted: Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50% off for beta teams.
    * [Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and…](20261002-7oozee.md) - Decision · accepted: Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Suggests Flat tiers: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.](20261002-7uodgg.md) - Finding · open: Suggests Flat tiers: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
