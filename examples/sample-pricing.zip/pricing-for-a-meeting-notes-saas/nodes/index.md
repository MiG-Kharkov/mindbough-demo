# Thought tree

* [Pricing for a meeting-notes SaaS](20261006-9d6g25.md) - Question · open: How to price a SaaS that turns meeting recordings into searchable notes: three pricing models compared, then the plans.
  * [How to price the meeting-notes SaaS at launch](20261006-an3jvi.md) - Question · accepted: Answered: Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Flat tiers](20261006-0f33a2.md) - Thought · accepted: A fixed price per team, with hours capped by tier.
      * [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](20261006-z3qjjm.md) - Decision · accepted: Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50% off for beta teams.
    * [Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and…](20261006-54ewe5.md) - Decision · accepted: Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Suggests Flat tiers: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.](20261006-enfneb.md) - Finding · open: Suggests Flat tiers: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Per seat](20261006-kbyfmr.md) - Thought · rejected: Not chosen: Simple, but heavy users eat the margin. Flat tiers was chosen.
    * [Usage-based](20261006-q4jha5.md) - Thought · rejected: Not chosen: Fair, but the bills worry small teams. Flat tiers was chosen.
