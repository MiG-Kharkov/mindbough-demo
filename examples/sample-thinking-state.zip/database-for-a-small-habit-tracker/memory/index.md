# Memory

* [I build side projects alone](20261002-hqh3qc.md) - I build side projects alone: prefer free tiers and managed services.
