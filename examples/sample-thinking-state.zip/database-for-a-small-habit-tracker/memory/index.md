# Memory

* [I build a habit tracker for a few friends](20261003-xgnn31.md) - I build a habit tracker for a few friends: about 100 users at most.
