---
type: Thinking State
title: "Database for a small habit tracker"
description: "Which database a small habit tracker for about 100 users should start on, and how to set it up in a weekend."
resource: "mindbough://20260930-owu5la"
thinking:
  profile: "0.2"
  id: 20260930-owu5la
  root: 20261006-wedxo9
generated: { by: "mindbough-demo/0.18.0", at: "2026-10-06T09:10:02Z" }
---

# Database for a small habit tracker

A Thinking State exported from the Mindbough demo on 2026-10-06. Start at the [thought tree](nodes/index.md): every branch of the conversation is a node, and every flagged message a decision.

The raw conversation is in `sessions/20261006-cnl1tk.jsonl`, which is git-ignored by default because conversations can hold private data.

To continue with an agent: `python3 skills/mindbough/scripts/mb.py context database-for-a-small-habit-tracker root`.
