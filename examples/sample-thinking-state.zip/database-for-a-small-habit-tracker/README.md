---
type: Thinking State
title: "Database for a small habit tracker"
description: "I'm building a small habit tracker for me and a few friends, maybe 100 users at most."
thinking:
  profile: "0.2"
  id: 20260930-owu5la
  root: 20261003-5bb1sj
generated: { by: "mindbough-demo/0.11.0", at: "2026-10-03T03:18:07Z" }
---

# Database for a small habit tracker

A Thinking State exported from the Mindbough demo on 2026-10-03. Start at the [thought tree](nodes/index.md): every branch of the conversation is a node, and every flagged message a decision.

The raw conversation is in `sessions/20260930-qkrqyc.jsonl`, which is git-ignored by default because conversations can hold private data.

To continue with an agent: `python3 skills/mindbough/scripts/mb.py context database-for-a-small-habit-tracker root`.
