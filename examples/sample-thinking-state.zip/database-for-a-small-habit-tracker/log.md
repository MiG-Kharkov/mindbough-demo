# Thinking log

## 2026-10-06
* **Decision**: [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](/nodes/20261006-9w4b0h.md), by human:me.
* **Decision**: [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](/nodes/20261006-dsfpkw.md), by human:me.
* **Decision**: [Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.](/nodes/20261006-c8150z.md) answers [Which database to start the habit tracker on](/nodes/20261006-22u5pr.md), by human:me.
* **Creation**: A conversation started in the Mindbough demo, by human:me.
