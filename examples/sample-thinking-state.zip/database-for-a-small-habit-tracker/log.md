# Thinking log

## 2026-10-03
* **Decision**: [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](/nodes/20261003-cdrlvf.md)
* **Decision**: [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](/nodes/20261003-ftqlgm.md)
* **Decision**: [Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.](/nodes/20261003-6e46ix.md) answers [Which database to start the habit tracker on](/nodes/20261003-w2l9e2.md).
* **Status**: [SQLite](/nodes/20261003-bipcqt.md) is rejected.
* **Status**: [PostgreSQL](/nodes/20261003-939mqd.md) is accepted.
* **Status**: [MongoDB](/nodes/20261003-w07sss.md) is rejected.
* **Creation**: “Database for a small habit tracker”, a conversation in the Mindbough demo.
