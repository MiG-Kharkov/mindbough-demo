# Thinking log

## 2026-10-06
* **Decision**: [Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.](/nodes/20261006-76a68t.md) answers [Which database to start the habit tracker on](/nodes/20261006-lo99wo.md).
* **Decision**: [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](/nodes/20261006-940vgv.md)
* **Decision**: [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](/nodes/20261006-7qf6fk.md)
* **Status**: [SQLite](/nodes/20261006-xnzuq3.md) is rejected.
* **Status**: [PostgreSQL](/nodes/20261006-c3v0mm.md) is accepted.
* **Status**: [MongoDB](/nodes/20261006-m7ggsk.md) is rejected.
* **Creation**: “Database for a small habit tracker”, a conversation in the Mindbough demo.
