# Thinking log

## 2026-10-02
* **Decision**: [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](/nodes/20261002-7yfjha.md)
* **Decision**: [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](/nodes/20261002-ynm900.md)
* **Decision**: [Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.](/nodes/20261002-259ik2.md) answers [Which database to start the habit tracker on](/nodes/20261002-kwx2xj.md).
* **Status**: [SQLite](/nodes/20261002-ka5pqf.md) is rejected.
* **Status**: [PostgreSQL](/nodes/20261002-zshzig.md) is accepted.
* **Status**: [MongoDB](/nodes/20261002-s3zwor.md) is rejected.
* **Creation**: “Database for a small habit tracker”, a conversation in the Mindbough demo.
