# Thought tree

* [Database for a small habit tracker](20261006-0ydm5r.md) - Question · open: I'm building a small habit tracker for me and a few friends, maybe 100 users at most.
  * [Which database to start the habit tracker on](20261006-lo99wo.md) - Question · accepted: Answered: Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.](20261006-76a68t.md) - Decision · accepted: Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [PostgreSQL](20261006-c3v0mm.md) - Thought · accepted: Relational and easy to grow, on a managed free tier.
      * [Weekend plan](20261006-0kdimd.md) - Thought · open: Give me a checklist to set this up this weekend.
        * [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](20261006-7qf6fk.md) - Decision · accepted: Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.
      * [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](20261006-940vgv.md) - Decision · accepted: Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.
    * [Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.](20261006-kykh6s.md) - Finding · open: Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.
    * [MongoDB](20261006-m7ggsk.md) - Thought · rejected: Not chosen: Easy now, awkward for reporting. PostgreSQL was chosen.
    * [SQLite](20261006-xnzuq3.md) - Thought · rejected: Not chosen: Simplest to start, but it caps growth. PostgreSQL was chosen.
