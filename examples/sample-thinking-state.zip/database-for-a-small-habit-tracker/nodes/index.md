# Thought tree

* [Database for a small habit tracker](20261003-5bb1sj.md) - Question · open: I'm building a small habit tracker for me and a few friends, maybe 100 users at most.
  * [Which database to start the habit tracker on](20261003-w2l9e2.md) - Question · accepted: Answered: Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [SQLite](20261003-bipcqt.md) - Thought · rejected: Not chosen: Simplest to start, but it caps growth. PostgreSQL was chosen.
    * [PostgreSQL](20261003-939mqd.md) - Thought · accepted: Relational and easy to grow, on a managed free tier.
      * [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](20261003-ftqlgm.md) - Decision · accepted: Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.
      * [Weekend plan](20261003-bpuxnw.md) - Thought · open: Give me a checklist to set this up this weekend.
        * [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](20261003-cdrlvf.md) - Decision · accepted: Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.
    * [Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.](20261003-6e46ix.md) - Decision · accepted: Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [MongoDB](20261003-w07sss.md) - Thought · rejected: Not chosen: Easy now, awkward for reporting. PostgreSQL was chosen.
    * [Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.](20261003-uz10u3.md) - Finding · open: Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.
