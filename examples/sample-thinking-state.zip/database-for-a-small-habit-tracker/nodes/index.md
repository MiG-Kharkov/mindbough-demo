# Thought tree

* [Database for a small habit tracker](20261006-wedxo9.md) - Question · open: Which database a small habit tracker for about 100 users should start on, and how to set it up in a weekend.
  * [Which database to start the habit tracker on](20261006-22u5pr.md) - Question · accepted: Answered: Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [PostgreSQL](20261006-0un70z.md) - Thought · accepted: Relational and easy to grow, on a managed free tier.
      * [Weekend plan](20261006-1kdbpt.md) - Thought · open: Give me a checklist to set this up this weekend.
        * [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](20261006-9w4b0h.md) - Decision · accepted: Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.
      * [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](20261006-dsfpkw.md) - Decision · accepted: Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.
    * [MongoDB](20261006-16s4ll.md) - Thought · rejected: Not chosen: Easy now, awkward for reporting. PostgreSQL was chosen.
    * [Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.](20261006-c8150z.md) - Decision · accepted: Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [SQLite](20261006-m29rmh.md) - Thought · rejected: Not chosen: Simplest to start, but it caps growth. PostgreSQL was chosen.
    * [Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.](20261006-vqqzmx.md) - Finding · open: Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.
