---
okf_version: "0.2"
---

# Thinking State

* [Database for a small habit tracker](README.md) - I'm building a small habit tracker for me and a few friends, maybe 100 users at most.
* [Thought tree](nodes/index.md) - 10 nodes
* [Memory](memory/index.md) - 1 item
* [Log](log.md) - how the thinking changed, newest first
