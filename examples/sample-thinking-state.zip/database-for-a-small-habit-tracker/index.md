---
okf_version: "0.2"
---

# Thinking State

* [Database for a small habit tracker](README.md) - Which database a small habit tracker for about 100 users should start on, and how to set it up in a weekend.
* [Thought tree](nodes/index.md) - 10 nodes
* [Memory](memory/index.md) - 1 item
* [Log](log.md) - how the thinking changed, newest first
