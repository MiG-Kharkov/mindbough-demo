# Memory

* [I am the on-call engineer](20261002-qktfok.md) - I am the on-call engineer: give me commands I can run.
