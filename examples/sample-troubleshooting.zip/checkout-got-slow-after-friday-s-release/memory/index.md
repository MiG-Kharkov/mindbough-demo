# Memory

* [I am the on-call engineer](20261001-8m9oq8.md) - I am the on-call engineer: give me commands I can run.
