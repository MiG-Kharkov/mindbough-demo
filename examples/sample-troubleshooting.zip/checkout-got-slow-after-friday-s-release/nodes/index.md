# Thought tree

* [Checkout got slow after Friday’s release](20261006-udqqmw.md) - Question · open: Why checkout got slow after Friday’s release: three suspects, one branch each, and the two fixes.
  * [What made checkout slow after Friday’s release](20261006-6562ab.md) - Question · open: A choice point: 3 options explored from here.
    * [Not alternatives: Two causes add up: the query slows every checkout on the server, the missing cache slows every…](20261006-2lm0n0.md) - Finding · open: Not alternatives: Two causes add up: the query slows every checkout on the server, the missing cache slows every repeat visit, and the widget was ruled out.
    * [Cache headers changed](20261006-4u0b6y.md) - Thought · accepted: Fits repeat visits being as slow as the first.
      * [Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.](20261006-id612z.md) - Decision · accepted: Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.
    * [A third-party script](20261006-7wna6n.md) - Thought · rejected: Fits a page that stalls after the HTML arrives.
    * [A slower database query](20261006-s9m4l1.md) - Thought · accepted: Fits a TTFB that grew after the release.
      * [Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.](20261006-sqr9b6.md) - Decision · accepted: Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.
  * [Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).](20261006-rd7pd7.md) - Decision · accepted: Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).
