# Thought tree

* [Checkout got slow after Friday’s release](20261006-uljv0h.md) - Question · open: I'm on call today.
  * [What made checkout slow after Friday’s release](20261006-okrslo.md) - Question · open: A choice point: 3 options explored from here.
    * [Not alternatives: Two causes add up: the query slows every checkout on the server, the missing cache slows every…](20261006-kjk4j2.md) - Finding · open: Not alternatives: Two causes add up: the query slows every checkout on the server, the missing cache slows every repeat visit, and the widget was ruled out.
    * [A third-party script](20261006-ok2355.md) - Thought · rejected: Fits a page that stalls after the HTML arrives.
    * [Cache headers changed](20261006-orhowz.md) - Thought · accepted: Fits repeat visits being as slow as the first.
      * [Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.](20261006-b0onzx.md) - Decision · accepted: Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.
    * [A slower database query](20261006-vb0tqk.md) - Thought · accepted: Fits a TTFB that grew after the release.
      * [Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.](20261006-c341sg.md) - Decision · accepted: Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.
  * [Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).](20261006-rdtfqo.md) - Decision · accepted: Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).
