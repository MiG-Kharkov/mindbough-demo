# Thought tree

* [Checkout got slow after Friday’s release](20261001-m299rp.md) - Question · open: I'm on call today.
  * [Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).](20261001-im2bsi.md) - Decision · accepted: Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).
  * [What made checkout slow after Friday’s release](20261001-zm9gqa.md) - Question · open: A choice point: 3 options explored from here.
    * [A slower database query](20261001-a54pal.md) - Thought · accepted: Fits a TTFB that grew after the release.
      * [Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.](20261001-qo02r3.md) - Decision · accepted: Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.
    * [Cache headers changed](20261001-grvugv.md) - Thought · accepted: Fits repeat visits being as slow as the first.
      * [Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.](20261001-01y8o6.md) - Decision · accepted: Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.
    * [A third-party script](20261001-zijw8b.md) - Thought · rejected: Fits a page that stalls after the HTML arrives.
    * [Not alternatives: Two causes add up: the query slows every checkout on the server, the missing cache slows every…](20261001-wxq3cn.md) - Finding · open: Not alternatives: Two causes add up: the query slows every checkout on the server, the missing cache slows every repeat visit, and the widget was ruled out.
