# Thinking log

## 2026-10-06
* **Decision**: [Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).](/nodes/20261006-rdtfqo.md), by human:me.
* **Status**: [A slower database query](/nodes/20261006-vb0tqk.md) is accepted, by human:me.
* **Status**: [Cache headers changed](/nodes/20261006-orhowz.md) is accepted, by human:me.
* **Decision**: [Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.](/nodes/20261006-b0onzx.md), by human:me.
* **Status**: [A third-party script](/nodes/20261006-ok2355.md) is rejected, by human:me.
* **Decision**: [Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.](/nodes/20261006-c341sg.md), by human:me.
* **Creation**: “Checkout got slow after Friday’s release”, a conversation in the Mindbough demo, by human:me.
