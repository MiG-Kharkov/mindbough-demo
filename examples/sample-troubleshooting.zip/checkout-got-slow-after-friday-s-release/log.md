# Thinking log

## 2026-10-02
* **Decision**: [Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).](/nodes/20261002-ypxlak.md)
* **Status**: [Cache headers changed](/nodes/20261002-t93ozq.md) is accepted.
* **Status**: [A slower database query](/nodes/20261002-4m384l.md) is accepted.
* **Status**: [A third-party script](/nodes/20261002-gr4plz.md) is rejected.
* **Decision**: [Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.](/nodes/20261002-x08vy6.md)
* **Decision**: [Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.](/nodes/20261002-3bud75.md)
* **Creation**: “Checkout got slow after Friday’s release”, a conversation in the Mindbough demo.
