# Thinking log

## 2026-10-06
* **Decision**: [Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).](/nodes/20261006-rd7pd7.md), by human:me.
* **Status**: [Cache headers changed](/nodes/20261006-4u0b6y.md) open → accepted, by human:me.
* **Status**: [A slower database query](/nodes/20261006-s9m4l1.md) open → accepted, by human:me.
* **Status**: [A third-party script](/nodes/20261006-7wna6n.md) open → rejected, by human:me.
* **Decision**: [Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.](/nodes/20261006-id612z.md), by human:me.
* **Decision**: [Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.](/nodes/20261006-sqr9b6.md), by human:me.
* **Creation**: A conversation started in the Mindbough demo, by human:me.
