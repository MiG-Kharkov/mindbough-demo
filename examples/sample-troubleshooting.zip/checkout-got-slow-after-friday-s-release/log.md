# Thinking log

## 2026-10-01
* **Decision**: [Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).](/nodes/20261001-im2bsi.md)
* **Status**: [Cache headers changed](/nodes/20261001-grvugv.md) is accepted.
* **Status**: [A slower database query](/nodes/20261001-a54pal.md) is accepted.
* **Status**: [A third-party script](/nodes/20261001-zijw8b.md) is rejected.
* **Decision**: [Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.](/nodes/20261001-01y8o6.md)
* **Decision**: [Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.](/nodes/20261001-qo02r3.md)
* **Creation**: “Checkout got slow after Friday’s release”, a conversation in the Mindbough demo.
