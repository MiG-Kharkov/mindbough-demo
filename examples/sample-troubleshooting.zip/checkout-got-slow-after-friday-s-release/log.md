# Thinking log

## 2026-10-03
* **Decision**: [Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).](/nodes/20261003-0stcvg.md)
* **Status**: [A slower database query](/nodes/20261003-u403hn.md) is accepted.
* **Status**: [Cache headers changed](/nodes/20261003-sr5jq2.md) is accepted.
* **Status**: [A third-party script](/nodes/20261003-rwh9gy.md) is rejected.
* **Decision**: [Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.](/nodes/20261003-9xbdny.md)
* **Decision**: [Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.](/nodes/20261003-wmy2k5.md)
* **Creation**: “Checkout got slow after Friday’s release”, a conversation in the Mindbough demo.
