---
okf_version: "0.2"
---

# Thinking State

* [Checkout got slow after Friday’s release](README.md) - Why checkout got slow after Friday’s release: three suspects, one branch each, and the two fixes.
* [Thought tree](nodes/index.md) - 9 nodes
* [Memory](memory/index.md) - 1 item
* [Log](log.md) - how the thinking changed, newest first
