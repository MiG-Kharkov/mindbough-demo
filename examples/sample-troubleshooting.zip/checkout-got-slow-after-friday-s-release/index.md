---
okf_version: "0.2"
---

# Thinking State

* [Checkout got slow after Friday’s release](README.md) - I'm on call today.
* [Thought tree](nodes/index.md) - 9 nodes
* [Memory](memory/index.md) - 1 item
* [Log](log.md) - how the thinking changed, newest first
