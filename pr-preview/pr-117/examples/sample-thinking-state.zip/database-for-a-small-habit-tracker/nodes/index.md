# Thought tree

* [Database for a small habit tracker](20260930-45lhmf.md) - Question · open: I'm building a small habit tracker for me and a few friends, maybe 100 users at most.
  * [Which database to start the habit tracker on](20260930-g9wiii.md) - Question · accepted: Answered: Chose PostgreSQL over SQLite, MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [SQLite](20260930-31a2lf.md) - Thought · rejected: Not chosen: One file and zero setup: plenty for 100 users.
    * [PostgreSQL](20260930-m08grk.md) - Thought · accepted: Relational and easy to grow, on a managed free tier.
      * [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](20260930-f4vdbd.md) - Decision · accepted: Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.
      * [Weekend plan](20260930-r3frf5.md) - Thought · open: Give me a checklist to set this up this weekend.
        * [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](20260930-eo59i7.md) - Decision · accepted: Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.
    * [Chose PostgreSQL over SQLite, MongoDB: check-ins are relational, and a managed free tier means no migration later.](20260930-r3qv08.md) - Decision · accepted: Chose PostgreSQL over SQLite, MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [MongoDB](20260930-1oplc4.md) - Thought · rejected: Not chosen: Flexible documents, quick to start.
    * [Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.](20260930-9u4adq.md) - Finding · open: Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.
