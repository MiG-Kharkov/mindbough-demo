# Thought tree

* [Pricing for a meeting-notes SaaS](20261001-z1y0p2.md) - Question · open: We're launching a SaaS that turns meeting recordings into searchable notes.
  * [How to price the meeting-notes SaaS at launch](20261001-cbgtgr.md) - Question · accepted: Answered: Chose Flat tiers over Per seat, Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Per seat](20261001-zc2hla.md) - Thought · rejected: Not chosen: Easy to explain, and it grows with the team.
    * [Usage-based](20261001-ss4x3e.md) - Thought · rejected: Not chosen: Revenue follows your cost per recorded hour.
    * [Flat tiers](20261001-0y4ppr.md) - Thought · accepted: A fixed price per team, with hours capped by tier.
      * [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50% o…](20261001-3vgrzt.md) - Decision · accepted: Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50% off for beta teams.
    * [Chose Flat tiers over Per seat, Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps th…](20261001-9e66jw.md) - Decision · accepted: Chose Flat tiers over Per seat, Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Suggests Flat tiers: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.](20261001-lyrwz6.md) - Finding · open: Suggests Flat tiers: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
