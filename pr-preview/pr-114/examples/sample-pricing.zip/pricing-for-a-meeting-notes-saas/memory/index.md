# Memory

* [I am a solo founder](20261001-5zjzi3.md) - I am a solo founder: show prices in euros, with the maths.
