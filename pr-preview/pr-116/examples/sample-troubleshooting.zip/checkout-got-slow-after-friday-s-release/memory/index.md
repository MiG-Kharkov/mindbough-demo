# Memory

* [I am the on-call engineer](20261001-xbb3tf.md) - I am the on-call engineer: give me commands I can run.
