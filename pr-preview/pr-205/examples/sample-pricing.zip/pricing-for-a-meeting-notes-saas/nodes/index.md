# Thought tree

* [Pricing for a meeting-notes SaaS](20261006-w25heh.md) - Question · open: We're launching a SaaS that turns meeting recordings into searchable notes.
  * [How to price the meeting-notes SaaS at launch](20261006-e0hl94.md) - Question · accepted: Answered: Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Suggests Flat tiers: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.](20261006-3ej9wc.md) - Finding · open: Suggests Flat tiers: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Flat tiers](20261006-6gq2x4.md) - Thought · accepted: A fixed price per team, with hours capped by tier.
      * [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](20261006-0j3yez.md) - Decision · accepted: Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50% off for beta teams.
    * [Per seat](20261006-hoxzy7.md) - Thought · rejected: Not chosen: Simple, but heavy users eat the margin. Flat tiers was chosen.
    * [Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and…](20261006-k9d4dy.md) - Decision · accepted: Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Usage-based](20261006-t6ii16.md) - Thought · rejected: Not chosen: Fair, but the bills worry small teams. Flat tiers was chosen.
