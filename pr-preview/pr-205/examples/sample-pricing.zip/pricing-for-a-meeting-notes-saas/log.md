# Thinking log

## 2026-10-06
* **Decision**: [Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and…](/nodes/20261006-k9d4dy.md) answers [How to price the meeting-notes SaaS at launch](/nodes/20261006-e0hl94.md), by human:me.
* **Decision**: [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](/nodes/20261006-0j3yez.md), by human:me.
* **Status**: [Per seat](/nodes/20261006-hoxzy7.md) is rejected, by human:me.
* **Status**: [Usage-based](/nodes/20261006-t6ii16.md) is rejected, by human:me.
* **Status**: [Flat tiers](/nodes/20261006-6gq2x4.md) is accepted, by human:me.
* **Creation**: “Pricing for a meeting-notes SaaS”, a conversation in the Mindbough demo, by human:me.
