# Thought tree

* [Database for a small habit tracker](20261006-7xpgze.md) - Question · open: I'm building a small habit tracker for me and a few friends, maybe 100 users at most.
  * [Which database to start the habit tracker on](20261006-6y6g28.md) - Question · accepted: Answered: Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [MongoDB](20261006-0o906r.md) - Thought · rejected: Not chosen: Easy now, awkward for reporting. PostgreSQL was chosen.
    * [PostgreSQL](20261006-17232k.md) - Thought · accepted: Relational and easy to grow, on a managed free tier.
      * [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](20261006-i9vqj3.md) - Decision · accepted: Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.
      * [Weekend plan](20261006-mjlojo.md) - Thought · open: Give me a checklist to set this up this weekend.
        * [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](20261006-dzuva9.md) - Decision · accepted: Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.
    * [Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.](20261006-kqqx75.md) - Decision · accepted: Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [SQLite](20261006-ri2tbc.md) - Thought · rejected: Not chosen: Simplest to start, but it caps growth. PostgreSQL was chosen.
    * [Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.](20261006-szggqq.md) - Finding · open: Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.
