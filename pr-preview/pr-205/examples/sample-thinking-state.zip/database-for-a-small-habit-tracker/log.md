# Thinking log

## 2026-10-06
* **Decision**: [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](/nodes/20261006-dzuva9.md), by human:me.
* **Decision**: [Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.](/nodes/20261006-kqqx75.md) answers [Which database to start the habit tracker on](/nodes/20261006-6y6g28.md), by human:me.
* **Decision**: [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](/nodes/20261006-i9vqj3.md), by human:me.
* **Status**: [SQLite](/nodes/20261006-ri2tbc.md) is rejected, by human:me.
* **Status**: [PostgreSQL](/nodes/20261006-17232k.md) is accepted, by human:me.
* **Status**: [MongoDB](/nodes/20261006-0o906r.md) is rejected, by human:me.
* **Creation**: “Database for a small habit tracker”, a conversation in the Mindbough demo, by human:me.
