# Memory

* [I am the on-call engineer](20261001-oz1ew7.md) - I am the on-call engineer: give me commands I can run.
