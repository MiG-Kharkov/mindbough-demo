---
type: Thinking State
title: "Database for a small habit tracker"
description: "Exported from a Mindbough demo conversation."
thinking:
  profile: "0.2"
  id: 20260930-owu5la
  root: 20261001-9n1lf8
generated: { by: "mindbough-demo/0.6.1", at: "2026-10-01T14:33:20Z" }
---

# Database for a small habit tracker

A Thinking State exported from the Mindbough demo on 2026-10-01. Start at the [thought tree](nodes/index.md): every branch of the conversation is a node, and every flagged message a decision.

The raw conversation is in `sessions/20260930-qkrqyc.jsonl`, which is git-ignored by default because conversations can hold private data.

To continue with an agent: `python3 skills/mindbough/scripts/mb.py context database-for-a-small-habit-tracker root`.
