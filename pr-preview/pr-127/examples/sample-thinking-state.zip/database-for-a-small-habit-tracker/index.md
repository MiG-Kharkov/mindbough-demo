---
okf_version: "0.2"
---

# Thinking State

* [Database for a small habit tracker](README.md) - Exported from a Mindbough demo conversation.
* [Thought tree](nodes/index.md) - 10 nodes
* [Memory](memory/index.md) - 1 item
* [Log](log.md) - how the thinking changed, newest first
