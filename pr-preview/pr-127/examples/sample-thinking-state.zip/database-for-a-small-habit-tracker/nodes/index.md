# Thought tree

* [Database for a small habit tracker](20261001-9n1lf8.md) - Question · open: I'm building a small habit tracker for me and a few friends, maybe 100 users at most.
  * [Which database to start the habit tracker on](20261001-oxs50u.md) - Question · accepted: Answered: Chose PostgreSQL over SQLite, MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [SQLite](20261001-75cktb.md) - Thought · rejected: Not chosen: Simplest to start, but it caps growth. PostgreSQL was chosen.
    * [PostgreSQL](20261001-juy9rk.md) - Thought · accepted: Relational and easy to grow, on a managed free tier.
      * [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](20261001-kq07nh.md) - Decision · accepted: Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.
      * [Weekend plan](20261001-jw83x0.md) - Thought · open: Give me a checklist to set this up this weekend.
        * [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](20261001-d3nj65.md) - Decision · accepted: Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.
    * [Chose PostgreSQL over SQLite, MongoDB: check-ins are relational, and a managed free tier means no migration later.](20261001-jawruo.md) - Decision · accepted: Chose PostgreSQL over SQLite, MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [MongoDB](20261001-bycsn6.md) - Thought · rejected: Not chosen: Easy now, awkward for reporting. PostgreSQL was chosen.
    * [Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.](20261001-cyxhfz.md) - Finding · open: Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.
