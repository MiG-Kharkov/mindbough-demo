# Thinking log

## 2026-10-01
* **Decision**: [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](/nodes/20261001-d3nj65.md)
* **Decision**: [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](/nodes/20261001-kq07nh.md)
* **Decision**: [Chose PostgreSQL over SQLite, MongoDB: check-ins are relational, and a managed free tier means no migration later.](/nodes/20261001-jawruo.md) answers [Which database to start the habit tracker on](/nodes/20261001-oxs50u.md).
* **Status**: [SQLite](/nodes/20261001-75cktb.md) is rejected.
* **Status**: [PostgreSQL](/nodes/20261001-juy9rk.md) is accepted.
* **Status**: [MongoDB](/nodes/20261001-bycsn6.md) is rejected.
* **Creation**: “Database for a small habit tracker”, a conversation in the Mindbough demo.
