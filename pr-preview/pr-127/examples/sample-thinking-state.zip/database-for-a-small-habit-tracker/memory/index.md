# Memory

* [I build side projects alone](20261001-gjz9u7.md) - I build side projects alone: prefer free tiers and managed services.
