# Thinking log

## 2026-10-06
* **Decision**: [Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).](/nodes/20261006-cwhde4.md)
* **Status**: [A slower database query](/nodes/20261006-txaqze.md) is accepted.
* **Status**: [Cache headers changed](/nodes/20261006-0t2eye.md) is accepted.
* **Decision**: [Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.](/nodes/20261006-ma4u3s.md)
* **Decision**: [Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.](/nodes/20261006-e05owo.md)
* **Status**: [A third-party script](/nodes/20261006-ykxn7v.md) is rejected.
* **Creation**: “Checkout got slow after Friday’s release”, a conversation in the Mindbough demo.
