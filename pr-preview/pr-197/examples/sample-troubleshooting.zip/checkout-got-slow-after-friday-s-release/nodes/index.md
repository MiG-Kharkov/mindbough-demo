# Thought tree

* [Checkout got slow after Friday’s release](20261006-ag0u86.md) - Question · open: I'm on call today.
  * [Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).](20261006-cwhde4.md) - Decision · accepted: Monday: index orders concurrently, restore static caching, purge the CDN, and re-measure checkout p95 (under 1.2 s).
  * [What made checkout slow after Friday’s release](20261006-fkglma.md) - Question · open: A choice point: 3 options explored from here.
    * [Cache headers changed](20261006-0t2eye.md) - Thought · accepted: Fits repeat visits being as slow as the first.
      * [Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.](20261006-e05owo.md) - Decision · accepted: Restore long caching for hashed static files, keep no-store for the API, and purge the CDN once.
    * [Not alternatives: Two causes add up: the query slows every checkout on the server, the missing cache slows every…](20261006-3bpdiv.md) - Finding · open: Not alternatives: Two causes add up: the query slows every checkout on the server, the missing cache slows every repeat visit, and the widget was ruled out.
    * [A slower database query](20261006-txaqze.md) - Thought · accepted: Fits a TTFB that grew after the release.
      * [Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.](20261006-ma4u3s.md) - Decision · accepted: Add the index orders (user_id, created_at desc) concurrently, then analyze orders and re-check the plan.
    * [A third-party script](20261006-ykxn7v.md) - Thought · rejected: Fits a page that stalls after the HTML arrives.
