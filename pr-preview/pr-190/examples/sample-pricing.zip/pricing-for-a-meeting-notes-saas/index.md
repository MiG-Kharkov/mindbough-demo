---
okf_version: "0.2"
---

# Thinking State

* [Pricing for a meeting-notes SaaS](README.md) - We're launching a SaaS that turns meeting recordings into searchable notes.
* [Thought tree](nodes/index.md) - 8 nodes
* [Memory](memory/index.md) - 1 item
* [Log](log.md) - how the thinking changed, newest first
