# Memory

* [We're launching a SaaS that turns meeting recordings into searchable…](20261003-ia8n0n.md) - We're launching a SaaS that turns meeting recordings into searchable notes, for teams of 3 to 10.
