# Thought tree

* [Pricing for a meeting-notes SaaS](20261006-gsyq7i.md) - Question · open: We're launching a SaaS that turns meeting recordings into searchable notes.
  * [How to price the meeting-notes SaaS at launch](20261006-xaunp8.md) - Question · accepted: Answered: Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Usage-based](20261006-2zz6ml.md) - Thought · rejected: Not chosen: Fair, but the bills worry small teams. Flat tiers was chosen.
    * [Suggests Flat tiers: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.](20261006-9r6pdi.md) - Finding · open: Suggests Flat tiers: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
    * [Flat tiers](20261006-i4ub5t.md) - Thought · accepted: A fixed price per team, with hours capped by tier.
      * [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](20261006-jrocc7.md) - Decision · accepted: Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50% off for beta teams.
    * [Per seat](20261006-ta7bol.md) - Thought · rejected: Not chosen: Simple, but heavy users eat the margin. Flat tiers was chosen.
    * [Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and…](20261006-tmrott.md) - Decision · accepted: Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and caps that protect the margin.
