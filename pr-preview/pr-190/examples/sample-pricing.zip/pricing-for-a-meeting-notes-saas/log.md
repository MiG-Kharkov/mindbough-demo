# Thinking log

## 2026-10-06
* **Decision**: [Chose Flat tiers over Per seat and Usage-based: the most revenue in the mix, a fixed price teams can plan for, and…](/nodes/20261006-tmrott.md) answers [How to price the meeting-notes SaaS at launch](/nodes/20261006-xaunp8.md).
* **Decision**: [Launch flat tiers (€19, €49, €129 with hour caps), a free plan of 3 hours, annual billing at two months free, and 50%…](/nodes/20261006-jrocc7.md)
* **Status**: [Per seat](/nodes/20261006-ta7bol.md) is rejected.
* **Status**: [Usage-based](/nodes/20261006-2zz6ml.md) is rejected.
* **Status**: [Flat tiers](/nodes/20261006-i4ub5t.md) is accepted.
* **Creation**: “Pricing for a meeting-notes SaaS”, a conversation in the Mindbough demo.
