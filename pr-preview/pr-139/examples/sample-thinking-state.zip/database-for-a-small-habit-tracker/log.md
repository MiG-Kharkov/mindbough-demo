# Thinking log

## 2026-10-01
* **Decision**: [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](/nodes/20261001-7urwed.md)
* **Decision**: [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](/nodes/20261001-mgh54g.md)
* **Decision**: [Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.](/nodes/20261001-mrjav1.md) answers [Which database to start the habit tracker on](/nodes/20261001-kjgy7b.md).
* **Status**: [SQLite](/nodes/20261001-7m3r2b.md) is rejected.
* **Status**: [PostgreSQL](/nodes/20261001-r1dd85.md) is accepted.
* **Status**: [MongoDB](/nodes/20261001-3tu8vc.md) is rejected.
* **Creation**: “Database for a small habit tracker”, a conversation in the Mindbough demo.
