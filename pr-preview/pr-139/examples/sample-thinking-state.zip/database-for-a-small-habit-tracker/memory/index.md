# Memory

* [I build side projects alone](20261001-cpd73o.md) - I build side projects alone: prefer free tiers and managed services.
