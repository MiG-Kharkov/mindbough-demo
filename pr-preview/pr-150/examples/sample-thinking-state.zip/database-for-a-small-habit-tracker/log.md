# Thinking log

## 2026-10-02
* **Decision**: [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](/nodes/20261002-1313ht.md)
* **Decision**: [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](/nodes/20261002-rg1d8i.md)
* **Decision**: [Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.](/nodes/20261002-vgkpfh.md) answers [Which database to start the habit tracker on](/nodes/20261002-yt5j1o.md).
* **Status**: [SQLite](/nodes/20261002-6acr9i.md) is rejected.
* **Status**: [PostgreSQL](/nodes/20261002-uz04b8.md) is accepted.
* **Status**: [MongoDB](/nodes/20261002-rew7ub.md) is rejected.
* **Creation**: “Database for a small habit tracker”, a conversation in the Mindbough demo.
