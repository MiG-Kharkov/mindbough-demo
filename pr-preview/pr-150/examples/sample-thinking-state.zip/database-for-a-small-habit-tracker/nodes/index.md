# Thought tree

* [Database for a small habit tracker](20261002-n9rxi9.md) - Question · open: I'm building a small habit tracker for me and a few friends, maybe 100 users at most.
  * [Which database to start the habit tracker on](20261002-yt5j1o.md) - Question · accepted: Answered: Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [SQLite](20261002-6acr9i.md) - Thought · rejected: Not chosen: Simplest to start, but it caps growth. PostgreSQL was chosen.
    * [PostgreSQL](20261002-uz04b8.md) - Thought · accepted: Relational and easy to grow, on a managed free tier.
      * [Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.](20261002-rg1d8i.md) - Decision · accepted: Use PostgreSQL with two tables, habits and check-ins, and one check-in per habit per day.
      * [Weekend plan](20261002-hxhg3a.md) - Thought · open: Give me a checklist to set this up this weekend.
        * [Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.](20261002-1313ht.md) - Decision · accepted: Set it up this weekend: a managed Postgres, the two tables, a check-in endpoint, streaks and daily backups.
    * [Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.](20261002-vgkpfh.md) - Decision · accepted: Chose PostgreSQL over SQLite and MongoDB: check-ins are relational, and a managed free tier means no migration later.
    * [MongoDB](20261002-rew7ub.md) - Thought · rejected: Not chosen: Easy now, awkward for reporting. PostgreSQL was chosen.
    * [Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.](20261002-m3qp33.md) - Finding · open: Suggests PostgreSQL: check-ins are relational, and a managed free tier means no migration later.
