# Memory

* [I build side projects alone](20261002-tvzlrm.md) - I build side projects alone: prefer free tiers and managed services.
